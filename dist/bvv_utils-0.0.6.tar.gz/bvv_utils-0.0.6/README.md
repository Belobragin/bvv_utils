# BelobraginVV utilites for kaggle competitions

## Installation

#From source:
#
#```
#git clone --recursive https://github.com/Belobragin/bvv_utils.git
#python setup.py install
#pip install git+https://github.com/Belobragin/bvv_utils.git
#```

Locally:

```
pip install bvv_utils
```

